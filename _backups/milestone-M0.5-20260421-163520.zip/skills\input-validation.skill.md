# input-validation

## purpose
Pr�ft Benutzereingaben auf Vollst�ndigkeit, Wertebereich und Plausibilit�t.

## use-when
- bei neuer Eingabe
- bei �nderungen
- vor jeder Entscheidung

## inputs
- projectName
- applicantName
- connectionLevel
- requestedCapacityKw
- estimatedAvailableCapacityKw
- loadProfileKnown
- siteSecured

## outputs
- valid
- errors[]
- warnings[]
- normalizedInput

## hard-rules
- Pflichtfelder pr�fen
- keine Berechnung
- keine Entscheidung
- nur validieren

## success-criteria
- Fehler sauber getrennt
- Warnungen separat
- strukturierte Ausgabe

## failure-mode
- valid = false bei Fehlern
